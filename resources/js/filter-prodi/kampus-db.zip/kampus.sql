-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 17. Nopember 2020 jam 00:08
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `e_arsip`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fakultas`
--

CREATE TABLE IF NOT EXISTS `fakultas` (
  `id_fakultas` int(3) NOT NULL AUTO_INCREMENT,
  `fakultas` varchar(100) NOT NULL,
  PRIMARY KEY (`id_fakultas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `fakultas`
--

INSERT INTO `fakultas` (`id_fakultas`, `fakultas`) VALUES
(1, 'Teknik'),
(2, 'Ekonomi'),
(3, 'FISIP'),
(4, 'FKIP'),
(5, 'Hukum'),
(6, 'FKM'),
(7, 'Pertanian'),
(8, 'Perikanan'),
(9, 'Ilmu Administrasi Negara (S2)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `prodi`
--

CREATE TABLE IF NOT EXISTS `prodi` (
  `id_prodi` int(3) NOT NULL AUTO_INCREMENT,
  `id_fakultas` int(3) NOT NULL,
  `prodi` varchar(100) NOT NULL,
  PRIMARY KEY (`id_prodi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `prodi`
--

INSERT INTO `prodi` (`id_prodi`, `id_fakultas`, `prodi`) VALUES
(1, 1, 'Teknik Sipil'),
(2, 1, 'Teknik Mesin'),
(3, 1, 'Teknik Informatika'),
(4, 2, 'Manajemen'),
(5, 2, 'Akuntansi'),
(6, 3, 'Ilmu Administrasi Negara (S1)'),
(7, 3, 'Sosiologi'),
(8, 4, 'Pendidikan Sejarah'),
(9, 4, 'Pendidikan Matematika'),
(10, 4, 'Pendidikan Bahasa Inggris'),
(11, 4, 'Pendidikan Ekonomi'),
(12, 5, 'Ilmu Hukum'),
(13, 6, 'Ilmu Kesehatan Masyarakat'),
(14, 7, 'Agroteknologi'),
(15, 8, 'Budidaya Perairan'),
(16, 9, 'Ilmu Administrasi Negara (S2)');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
